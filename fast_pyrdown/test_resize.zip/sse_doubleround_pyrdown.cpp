//
//  sse_doubleround_pyrdown.cpp
//  fast_pyrdown
//
//  Created by Alexander Graschenkov on 22.12.2022.
//

#include "sse_doubleround_pyrdown.hpp"
#include "sse2neon.h"
//#include <emmintrin.h>
//#include <immintrin.h>
#include <cmath>

// SSSE3 version
// I used `__restrict__` to give the compiler more flexibility in unrolling
void average2Rows_doubleround(const uint8_t* __restrict__ src1,
                              const uint8_t*__restrict__ src2,
                              uint8_t*__restrict__ dst,
                              size_t size,
                              const __m128i *lastStoreMask = nullptr)
{
    const __m128i vk1 = _mm_set1_epi8(1);
    size_t dstsize = size/2;
    for (size_t i = 0; i < dstsize - 15; i += 16)
    {
        __m128i v0 = _mm_load_si128((const __m128i *)&src1[i*2]);
        __m128i v1 = _mm_load_si128((const __m128i *)&src1[i*2 + 16]);
        __m128i v2 = _mm_load_si128((const __m128i *)&src2[i*2]);
        __m128i v3 = _mm_load_si128((const __m128i *)&src2[i*2 + 16]);
        __m128i left  = _mm_avg_epu8(v0, v2);
        __m128i right = _mm_avg_epu8(v1, v3);

        __m128i w0 = _mm_maddubs_epi16(left, vk1);        // unpack and horizontal add
        __m128i w1 = _mm_maddubs_epi16(right, vk1);
        w0 = _mm_srli_epi16(w0, 1);                     // divide by 2
        w1 = _mm_srli_epi16(w1, 1);
        w0 = _mm_packus_epi16(w0, w1);                  // pack

        if (lastStoreMask && i+31 >= dstsize) {
            // store with mask
            _mm_maskmoveu_si128 (w0, *lastStoreMask, (char *)&dst[i]);
        } else {
            // store whole number
            _mm_storeu_si128((__m128i *)&dst[i], w0);
        }
        
    }
}
void average3Rows_doubleround(const uint8_t* __restrict__ src1, const uint8_t*__restrict__ src2,
                              uint8_t*__restrict__ dst, size_t size)
{
    const __m128i vk1 = _mm_set1_epi8(1);
    size_t dstsize = size/2;
    for (size_t i = 0; i < dstsize - 15; i += 16)
    {
        __m128i v0 = _mm_load_si128((const __m128i *)&src1[i*2]);
        __m128i v1 = _mm_load_si128((const __m128i *)&src1[i*2 + 16]);
        __m128i v2 = _mm_load_si128((const __m128i *)&src2[i*2]);
        __m128i v3 = _mm_load_si128((const __m128i *)&src2[i*2 + 16]);
        __m128i left  = _mm_avg_epu8(v0, v2);
        __m128i right = _mm_avg_epu8(v1, v3);

        __m128i w0 = _mm_maddubs_epi16(left, vk1);        // unpack and horizontal add
        __m128i w1 = _mm_maddubs_epi16(right, vk1);
        w0 = _mm_srli_epi16(w0, 1);                     // divide by 2
        w1 = _mm_srli_epi16(w1, 1);
        w0 = _mm_packus_epi16(w0, w1);                  // pack

        _mm_storeu_si128((__m128i *)&dst[i], w0);
    }
}


//void average2RowsF_doubleround(const float* __restrict__ src1, const float*__restrict__ src2,
//                               float*__restrict__ dst, size_t size)
//{
//    size_t dstsize = size/2;
//    std::vector<uint8_t> testData(20, 0);
//    std::vector<int16_t> testData2(20, 0);
//    for (size_t i = 0; i < dstsize - 15; i += 16)
//    {
//        __m128i v0 = _mm_load_ps(&src1[i*2]);
//        __m128i v1 = _mm_load_ps(&src1[i*2 + 16]);
//        __m128i v2 = _mm_load_ps(&src2[i*2]);
//        __m128i v3 = _mm_load_ps(&src2[i*2 + 16]);
//        __m128i left  = _mm_hadd_ps(v0, v2);
//        __m128i right = _mm_hadd_ps(v1, v3);
//
//        __m128i w0 = _mm_maddubs_epi16(left, vk1);        // unpack and horizontal add
//        _mm_storeu_si128((__m128i *)(testData2.data)(), w0);
//        __m128i w1 = _mm_maddubs_epi16(right, vk1);
//        w0 = _mm_srli_epi16(w0, 1);                     // divide by 2
//        _mm_storeu_si128((__m128i *)(testData.data)(), w0);
//        w1 = _mm_srli_epi16(w1, 1);
//        w0 = _mm_packus_epi16(w0, w1);                  // pack
//        _mm_storeu_si128((__m128i *)(testData.data)(), w0);
//
//        _mm_storeu_si128((__m128i *)&dst[i], w0);
//    }
//}


using namespace std;
void sse2Pyrdown(const uint8_t *image, int height, int width, std::vector<uint8_t> &out) {
    const int half_width = width / 2;
    const int half_height = height / 2;
    out.resize(half_width * half_height);
    vector<uint8_t> &half_image = out;
    
    const int width_rest32 = width % 32;
    bool process_rest_manual_approach = width_rest32 > 0 && width_rest32 < 5;
    for (int r = 0; r < half_height; r++) {
        const int offset = r * 2 * width;
        const int half_offset = r * half_width;
        
        int process_width = ceilf(width / 32.f) * 32;
        if (r == half_height-1 || process_rest_manual_approach) {
            process_width = floorf(width / 32.f) * 32;
        }
        average2Rows_doubleround(&image[offset], &image[offset+width], &half_image[half_offset], process_width);
        
        // process rest of line
        for (int c = process_width; c < width; c += 2) {
            out[half_offset + c/2] = ((int)image[offset+c] +
                                      (int)image[offset+c+1] +
                                      (int)image[offset+width+c] +
                                      (int)image[offset+width+c+1]) / 4;
        }
    }
}

void sse2Pyrdown(const float *image, int height, int width, std::vector<float> &out) {
    const int half_width = width / 2;
    const int half_height = height / 2;
    out.resize(half_width * half_height);
    vector<float> &half_image = out;
    for (int r = 0; r < half_height; r++) {
        const int offset = r * 2 * width;
        const int half_offset = r * half_width;
        
        const int process_width = (width / 32) * 32;
//        average2Rows_doubleround(&image[offset], &image[offset+width], &half_image[half_offset], process_width);
        for (int c = process_width; c < width; c += 2) {
//            out[half_offset + c/2] = 100;
            out[half_offset + c/2] = ((int)image[offset+c] +
                                      (int)image[offset+c+1] +
                                      (int)image[offset+width+c] +
                                      (int)image[offset+width+c+1]) / 4;
        }
    }
}
