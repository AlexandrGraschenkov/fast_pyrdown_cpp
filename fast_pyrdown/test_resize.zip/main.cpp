//
//  main.cpp
//  fast_pyrdown
//
//  Created by Alexander Graschenkov on 22.12.2022.
//

#include <iostream>
#include <opencv2/core.hpp>
#define SIMD_OPENCV_ENABLE
#include "SimdLib.hpp"
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>
#include "eigen_pyrdown.hpp"
#include "sse_doubleround_pyrdown.hpp"
#include "rbenchmark.hpp"
#include "sse2neon.h"

using namespace cv;
using namespace std;


typedef Simd::View<Simd::Allocator> View;

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    Simd::PrintInfo(cout);
    
//    vector<uint8_t> testData = {128, 0, 0, 0, 255, 0, 7, 8, 0, 10, 11, 0, 13, 14, 0, 16};
//    vector<uint8_t> testOut = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16};
////    vector<uint8_t> testData = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16};
//
//    __m128 v = _mm_load_si128((const __m128i *)testData.data());
////    __m128 v = _mm_set_epi8(127, 0, 14, 13, 0, 11, 10, 0, 8, 7, 0, 0, 0, 0, 0, 0);
//    int v2 = _mm_movemask_epi8(v);
//    for (int i = 0; i < 32; ++i) {
//        cout << i << " <> " << ((v2 >> i) & 1) << endl;
//    }
//    return 0;
//    const __m128 t1 = _mm_movehl_ps(v, v);
//    const __m128 t2 = _mm_add_ps(v, t1);
//    const __m128 sum = _mm_add_ss(t1, _mm_shuffle_ps(t2, t2, 1));
//    _mm_storeu_si128((__m128i *)testOut.data(), sum);
//    for (int i = 0; i < testOut.size(); i++) {
//        cout << i << " > " << (int)testOut[i] << endl;
//    }
//    return 0;
    
    cv::Mat img = imread("/Users/alex/Desktop/2022-12-16_15-00-00/snapshot_0.jpg",  IMREAD_GRAYSCALE);
//    cv::Mat img = imread("/Users/alex/Downloads/image_processing20201123-8941-1um70ga.jpg",  IMREAD_GRAYSCALE);
    cv::Mat imgF;
//    img(Rect(0, 0, img.cols-30, img.rows-1)).copyTo(img);
    img.convertTo(imgF, CV_32F);
    cv::Mat small, smallResize, smallF, smallSimd(img.rows/2, img.cols/2, CV_8UC1);
    View largeS = img;
    View smallS = smallSimd;
    std::vector<uint8_t> small2Vec;
    std::vector<float> small2VecF;
    for (int i = 0; i < 300; i++) {
        R_BENCHMARK("sse") {
            sse2Pyrdown(img.data, img.rows, img.cols, small2Vec);
        }
        R_BENCHMARK("cv_pyrdown") {
            cv::pyrDown(img, small);
        }
        R_BENCHMARK("cv_resize") {
            cv::resize(img, smallResize, img.size() / 2, 0, 0, INTER_LINEAR);
        }
        R_BENCHMARK("simd") {
            
            Simd::ResizeAreaGray(largeS, smallS);
        }
        cout << (int)small.data[0] << " <> "
        << (int)small2Vec[0] << " <> "
        << (int)smallSimd.data[0] << " <> "
        << (int)smallResize.data[0] << endl;
//        cout << (int)small.data[0] << " <> " << (int)small2Vec[0] << " <> " << (int)smallResize.data[0] << endl;
//        cout << (int)small.data[0] << " <> " << (int)small2Vec[0] << endl;
    }
    
    
//    for (int i = 0; i < 100; i++) {
//        R_BENCHMARK("cv_f") {
//            cv::pyrDown(imgF, smallF);
//        }
//        R_BENCHMARK("eigen_f") {
//            eigenPyrdown<float>((float*)imgF.data, img.rows, img.cols, small2VecF);
//        }
//        cout << (int)(((float*)smallF.data)[0]) << " <> " << (int)small2Vec[0] << endl;
//    }
    
    cout << R_BENCHMARK_LOG() << endl;
    cv::Mat small2(img.rows/2, img.cols/2, CV_8UC1, small2Vec.data());
    
    imwrite("/Users/alex/Downloads/result.png", small2);
    cout << "Size 1: " << small.size() << endl;
    cout << "Size 2: " << small2.size() << endl;
    imshow("small_1", small);
    imshow("small_2", small2);
    waitKey();
    
    return 0;
}
